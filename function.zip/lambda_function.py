import boto3
import gzip
import io
import json
import re
from datetime import datetime

s3_client = boto3.client("s3")
logs_client = boto3.client("logs")

LOG_GROUP_NAME = "/aws/s3/access-logs"

def parse_s3_log(log_content):
    log_entries = []
    for line in log_content.splitlines():
        if line.startswith("#"):  # Skip comments
            continue
        fields = line.split()
        if len(fields) < 10:
            continue  # Skip malformed lines

        log_entry = {
            "bucket_owner": fields[0],
            "bucket": fields[1],
            "time": fields[2] + " " + fields[3],
            "requester": fields[4],
            "request_id": fields[5],
            "operation": fields[6],
            "key": fields[7] if fields[7] != "-" else None,
            "request_uri": fields[8],
            "status_code": fields[9],
        }
        log_entries.append(log_entry)
    return log_entries

def lambda_handler(event, context):
    for record in event["Records"]:
        bucket_name = record["s3"]["bucket"]["name"]
        object_key = record["s3"]["object"]["key"]

        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        content = response["Body"].read()

        # If file is gzipped, decompress it
        if object_key.endswith(".gz"):
            with gzip.GzipFile(fileobj=io.BytesIO(content)) as f:
                log_content = f.read().decode("utf-8")
        else:
            log_content = content.decode("utf-8")

        log_entries = parse_s3_log(log_content)

        # Send logs to CloudWatch
        log_stream_name = datetime.utcnow().strftime("%Y-%m-%d-%H-%M-%S")
        logs_client.create_log_stream(logGroupName=LOG_GROUP_NAME, logStreamName=log_stream_name)

        log_events = [
            {
                "timestamp": int(datetime.utcnow().timestamp() * 1000),
                "message": json.dumps(entry),
            }
            for entry in log_entries
        ]

        if log_events:
            logs_client.put_log_events(
                logGroupName=LOG_GROUP_NAME,
                logStreamName=log_stream_name,
                logEvents=log_events,
            )

    return {"status": "success"}
